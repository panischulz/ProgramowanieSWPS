from setuptools import setup

setup(
    name='mojabiblioteka',
    version='1.0.0',
    description='my_first_library',
    url='',
    author='agataschulz',
    author_email='aschulz3@st.swps.edu.pl',
    licence='for internal use', 
    keywords='library'
)